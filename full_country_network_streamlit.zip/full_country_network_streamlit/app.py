
import math
from pathlib import Path

import networkx as nx
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

st.set_page_config(page_title="Global fuel-country network", layout="wide")

BASE_DIR = Path(__file__).resolve().parent
EDGES_PATH = BASE_DIR / "edges_detailed.csv"
NODES_PATH = BASE_DIR / "country_nodes.csv"


@st.cache_data
def load_data():
    edges = pd.read_csv(EDGES_PATH)
    nodes = pd.read_csv(NODES_PATH)
    nodes["country"] = nodes["country"].astype(str)
    return edges, nodes


def aggregate_edges(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame(
            columns=[
                "source", "target", "total_mentions", "dominant_relation",
                "relation_summary", "years", "sheets", "sample_evidence"
            ]
        )

    grouped = (
        df.groupby(["source", "target"], dropna=False)
        .agg(
            total_mentions=("sentence", "count"),
            years=("year_label", lambda s: ", ".join(sorted(set(map(str, s))))),
            sheets=("sheet", lambda s: "; ".join(sorted(set(map(str, s))))),
            sample_evidence=("sentence", lambda s: " || ".join(list(dict.fromkeys(map(str, s)))[:3])),
            relation_summary=("relation_type", lambda s: ", ".join(
                f"{k} ({v})" for k, v in pd.Series(list(s)).value_counts().to_dict().items()
            )),
            dominant_relation=("relation_type", lambda s: pd.Series(list(s)).value_counts().idxmax()),
        )
        .reset_index()
    )
    return grouped.sort_values(["total_mentions", "source", "target"], ascending=[False, True, True])


def compute_node_metrics(edge_pairs: pd.DataFrame, nodes: pd.DataFrame) -> pd.DataFrame:
    meta = nodes.copy()
    meta["in_degree"] = 0
    meta["out_degree"] = 0
    meta["weighted_in"] = 0
    meta["weighted_out"] = 0

    if edge_pairs.empty:
        meta["weighted_total"] = 0
        meta["degree_total"] = 0
        return meta

    out_counts = edge_pairs.groupby("source").agg(
        out_degree=("target", "nunique"),
        weighted_out=("total_mentions", "sum"),
    )
    in_counts = edge_pairs.groupby("target").agg(
        in_degree=("source", "nunique"),
        weighted_in=("total_mentions", "sum"),
    )

    meta = meta.merge(out_counts, left_on="country", right_index=True, how="left", suffixes=("", "_new"))
    meta = meta.merge(in_counts, left_on="country", right_index=True, how="left", suffixes=("", "_new"))

    for col in ["in_degree", "out_degree", "weighted_in", "weighted_out"]:
        if f"{col}_new" in meta.columns:
            meta[col] = meta[f"{col}_new"].fillna(meta[col]).fillna(0).astype(float)
            meta.drop(columns=[f"{col}_new"], inplace=True)

    meta["weighted_total"] = meta["weighted_in"] + meta["weighted_out"]
    meta["degree_total"] = meta["in_degree"] + meta["out_degree"]
    return meta


def build_plot(edge_pairs: pd.DataFrame, node_metrics: pd.DataFrame, show_labels: bool = True) -> go.Figure:
    fig = go.Figure()
    if edge_pairs.empty:
        fig.update_layout(
            title="No links match the current filters.",
            xaxis={"visible": False},
            yaxis={"visible": False},
            plot_bgcolor="white",
            paper_bgcolor="white",
        )
        return fig

    graph = nx.DiGraph()
    for _, row in edge_pairs.iterrows():
        graph.add_edge(row["source"], row["target"], weight=float(row["total_mentions"]))

    undirected = graph.to_undirected()
    pos = nx.spring_layout(undirected, seed=42, k=1.2 / max(1, math.sqrt(max(1, undirected.number_of_nodes()))), weight="weight")

    region_color = {
        "EAP": "#1f77b4",
        "ECA": "#9467bd",
        "LAC": "#2ca02c",
        "MENA": "#ff7f0e",
        "NAC": "#8c564b",
        "SAS": "#d62728",
        "SSA": "#17becf",
    }
    relation_color = {
        "imports": "#1f77b4",
        "exports": "#2ca02c",
        "smuggling": "#d62728",
        "other reference": "#7f7f7f",
        "payment constraint": "#9467bd",
    }

    # Edge lines grouped by dominant relation
    for rel, group in edge_pairs.groupby("dominant_relation"):
        xs, ys = [], []
        hover_x, hover_y, hover_text = [], [], []
        for _, row in group.iterrows():
            x0, y0 = pos[row["source"]]
            x1, y1 = pos[row["target"]]
            xs += [x0, x1, None]
            ys += [y0, y1, None]
            hover_x.append((x0 + x1) / 2)
            hover_y.append((y0 + y1) / 2)
            hover_text.append(
                f"<b>{row['source']} → {row['target']}</b><br>"
                f"Mentions: {int(row['total_mentions'])}<br>"
                f"Relations: {row['relation_summary']}<br>"
                f"Years: {row['years']}<br>"
                f"Sheets: {row['sheets']}<br>"
                f"Evidence: {row['sample_evidence']}"
            )

        fig.add_trace(
            go.Scatter(
                x=xs,
                y=ys,
                mode="lines",
                line={"width": 1.0, "color": relation_color.get(rel, "#7f7f7f")},
                hoverinfo="skip",
                name=f"Edges: {rel}",
                opacity=0.55,
            )
        )
        fig.add_trace(
            go.Scatter(
                x=hover_x,
                y=hover_y,
                mode="markers",
                marker={"size": 10, "opacity": 0.0},
                hoverinfo="text",
                hovertext=hover_text,
                showlegend=False,
                name=f"Hover: {rel}",
            )
        )

    node_metrics = node_metrics[node_metrics["country"].isin(set(edge_pairs["source"]).union(edge_pairs["target"]))].copy()
    node_metrics["x"] = node_metrics["country"].map(lambda c: pos[c][0])
    node_metrics["y"] = node_metrics["country"].map(lambda c: pos[c][1])
    node_metrics["size"] = node_metrics["weighted_total"].apply(lambda v: 10 + 4 * math.sqrt(max(v, 0)))

    for region, group in node_metrics.groupby("region"):
        text_values = group["country"].tolist() if show_labels else None
        fig.add_trace(
            go.Scatter(
                x=group["x"],
                y=group["y"],
                mode="markers+text" if show_labels else "markers",
                text=text_values,
                textposition="top center",
                marker={
                    "size": group["size"],
                    "color": region_color.get(region, "#7f7f7f"),
                    "line": {"width": 0.5, "color": "#333333"},
                    "opacity": 0.95,
                },
                name=f"Region: {region}",
                hoverinfo="text",
                hovertext=[
                    (
                        f"<b>{row.country}</b><br>"
                        f"Code: {row.code}<br>"
                        f"Region: {row.region}<br>"
                        f"Outgoing links: {int(row.out_degree)}<br>"
                        f"Incoming links: {int(row.in_degree)}<br>"
                        f"Weighted outgoing: {int(row.weighted_out)}<br>"
                        f"Weighted incoming: {int(row.weighted_in)}"
                    )
                    for row in group.itertuples()
                ],
            )
        )

    fig.update_layout(
        title="Country network extracted from the workbook narratives",
        xaxis={"visible": False},
        yaxis={"visible": False},
        plot_bgcolor="white",
        paper_bgcolor="white",
        hovermode="closest",
        margin={"l": 10, "r": 10, "t": 50, "b": 10},
        legend={"orientation": "h", "yanchor": "bottom", "y": 1.02, "x": 0},
        height=850,
    )
    return fig


edges_raw, nodes = load_data()
all_relation_types = sorted(edges_raw["relation_type"].dropna().unique().tolist())
all_years = sorted(edges_raw["year_label"].dropna().unique().tolist(), key=lambda x: (x == "Trade Status", x))

st.title("Global fuel-country relationship network")
st.caption(
    "Built from the uploaded workbook's narrative sheets. "
    "Default view emphasizes higher-confidence links such as imports, exports, and smuggling."
)

with st.sidebar:
    st.header("Filters")
    confidence_mode = st.radio(
        "Confidence",
        options=["High-confidence only", "Include lower-confidence mentions"],
        index=0,
    )
    min_conf = 0.75 if confidence_mode == "High-confidence only" else 0.0

    relation_types = st.multiselect(
        "Relation types",
        options=all_relation_types,
        default=[r for r in ["imports", "exports", "smuggling"] if r in all_relation_types],
    )

    years = st.multiselect(
        "Years / trade-status layer",
        options=all_years,
        default=all_years,
    )

    focus_countries = st.multiselect(
        "Focus countries",
        options=sorted(nodes["country"].tolist()),
        default=["Thailand"] if "Thailand" in nodes["country"].values else [],
    )

    focus_mode = st.radio(
        "When focus countries are selected",
        options=["Show links touching any focus country", "Show only links between selected countries"],
        index=0,
    )

    min_mentions = st.slider("Minimum mentions per link", 1, 5, 1)
    max_nodes = st.slider("Maximum countries shown in graph", 20, max(20, len(nodes)), 80)
    show_labels = st.checkbox("Show country labels", value=True)
    show_isolates = st.checkbox("Show isolated countries in tables", value=False)

filtered = edges_raw.copy()
filtered = filtered[filtered["confidence"] >= min_conf]
if relation_types:
    filtered = filtered[filtered["relation_type"].isin(relation_types)]
if years:
    filtered = filtered[filtered["year_label"].isin(years)]

if focus_countries:
    focus_set = set(focus_countries)
    if focus_mode == "Show links touching any focus country":
        filtered = filtered[(filtered["source"].isin(focus_set)) | (filtered["target"].isin(focus_set))]
    else:
        filtered = filtered[(filtered["source"].isin(focus_set)) & (filtered["target"].isin(focus_set))]

edge_pairs = aggregate_edges(filtered)
edge_pairs = edge_pairs[edge_pairs["total_mentions"] >= min_mentions].copy()

node_metrics = compute_node_metrics(edge_pairs, nodes)

if focus_countries:
    selected_nodes = set(edge_pairs["source"]).union(edge_pairs["target"])
else:
    ranked_nodes = node_metrics.sort_values(["weighted_total", "degree_total", "country"], ascending=[False, False, True])
    selected_nodes = set(ranked_nodes.head(max_nodes)["country"])

edge_pairs_graph = edge_pairs[
    edge_pairs["source"].isin(selected_nodes) & edge_pairs["target"].isin(selected_nodes)
].copy()
node_metrics_graph = compute_node_metrics(edge_pairs_graph, nodes)
fig = build_plot(edge_pairs_graph, node_metrics_graph, show_labels=show_labels)

metric_cols = st.columns(4)
metric_cols[0].metric("Countries shown", len(set(edge_pairs_graph["source"]).union(edge_pairs_graph["target"])))
metric_cols[1].metric("Pairwise links shown", len(edge_pairs_graph))
metric_cols[2].metric("Detailed mentions in filter", len(filtered))
metric_cols[3].metric("High-confidence cutoff", f"{min_conf:.2f}")

graph_tab, edge_tab, country_tab = st.tabs(["Network graph", "Edge table", "Country explorer"])

with graph_tab:
    st.plotly_chart(fig, use_container_width=True)
    st.caption(
        "Node size reflects total weighted degree in the filtered network. "
        "Node color reflects World Bank region. Edge color reflects the dominant relation type for that country pair."
    )

with edge_tab:
    display_edges = edge_pairs.copy()
    if not show_isolates:
        active_countries = set(display_edges["source"]).union(display_edges["target"])
        display_nodes = node_metrics[node_metrics["country"].isin(active_countries)].copy()
    else:
        display_nodes = node_metrics.copy()

    st.subheader("Aggregated links")
    st.dataframe(display_edges, use_container_width=True, hide_index=True)
    st.download_button(
        "Download filtered links as CSV",
        data=display_edges.to_csv(index=False).encode("utf-8"),
        file_name="filtered_country_links.csv",
        mime="text/csv",
    )

    st.subheader("Country metrics")
    st.dataframe(
        display_nodes.sort_values(["weighted_total", "degree_total", "country"], ascending=[False, False, True]),
        use_container_width=True,
        hide_index=True,
    )

with country_tab:
    country_choice = st.selectbox("Choose a country", options=sorted(nodes["country"].tolist()), index=sorted(nodes["country"].tolist()).index("Thailand") if "Thailand" in nodes["country"].tolist() else 0)

    outgoing = edge_pairs[edge_pairs["source"] == country_choice].sort_values("total_mentions", ascending=False)
    incoming = edge_pairs[edge_pairs["target"] == country_choice].sort_values("total_mentions", ascending=False)

    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"### Outgoing from {country_choice}")
        st.dataframe(outgoing, use_container_width=True, hide_index=True)
    with col2:
        st.markdown(f"### Incoming to {country_choice}")
        st.dataframe(incoming, use_container_width=True, hide_index=True)

    related_detail = filtered[(filtered["source"] == country_choice) | (filtered["target"] == country_choice)].copy()
    st.markdown("### Supporting evidence")
    st.dataframe(
        related_detail[["source", "target", "relation_type", "year_label", "sheet", "sentence"]]
        .sort_values(["year_label", "source", "target"], ascending=[True, True, True]),
        use_container_width=True,
        hide_index=True,
    )
