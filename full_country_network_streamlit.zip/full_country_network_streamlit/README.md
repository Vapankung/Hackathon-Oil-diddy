# Global fuel-country network Streamlit app

This package contains a Streamlit app built from the uploaded workbook:

- `Global_Fuel_Subsidies_and_Price_Control_Measures_Database.xlsx`

## Files
- `app.py` — Streamlit app
- `edges_detailed.csv` — extracted country-to-country references with evidence text
- `country_nodes.csv` — country metadata
- `dataset_summary.json` — quick summary of extraction coverage
- `requirements.txt` — suggested Python packages

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Notes
- The default view shows higher-confidence links only.
- Link types are inferred from workbook text, mainly:
  - imports
  - exports
  - smuggling
- The app also lets you include lower-confidence country mentions if you want a broader network.
